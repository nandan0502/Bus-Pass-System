from django.urls import path
from . import views

urlpatterns = [
    path('admin/login/', views.admin_login, name='admin_login'),
    path('admin/dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('register/', views.register, name='register'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('apply/', views.apply_bus_pass, name='apply_pass'),
    path('payment/<int:payment_id>/', views.payment_process, name='payment_process'),
    path('profile/', views.profile, name='profile'),
    path('verify/', views.verify_pass, name='verify_pass'),
]