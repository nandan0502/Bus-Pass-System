from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from django.core.validators import MinValueValidator

class Station(models.Model):
    name = models.CharField(max_length=100)
    address = models.TextField()
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

class Route(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    stations = models.ManyToManyField(Station, through='RouteStation')
    distance = models.DecimalField(max_digits=8, decimal_places=2, help_text='Distance in kilometers')
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

class RouteStation(models.Model):
    route = models.ForeignKey(Route, on_delete=models.CASCADE)
    station = models.ForeignKey(Station, on_delete=models.CASCADE)
    sequence = models.PositiveIntegerField()
    distance_from_start = models.DecimalField(max_digits=8, decimal_places=2, help_text='Distance from start in kilometers')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['sequence']
        unique_together = [['route', 'sequence']]

    def __str__(self):
        return f"{self.route.name} - {self.station.name} (Stop {self.sequence})"

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone_number = models.CharField(max_length=15)
    address = models.TextField()
    id_proof = models.ImageField(upload_to='id_proofs/')
    preferred_routes = models.ManyToManyField(Route, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user.username}'s Profile"

class BusPass(models.Model):
    PASS_TYPES = [
        ('daily', 'Daily Pass'),
        ('weekly', 'Weekly Pass'),
        ('monthly', 'Monthly Pass'),
        ('quarterly', 'Quarterly Pass'),
        ('yearly', 'Yearly Pass'),
    ]

    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('submitted', 'Submitted'),
        ('under_review', 'Under Review'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
        ('active', 'Active'),
        ('expired', 'Expired'),
        ('cancelled', 'Cancelled'),
    ]

    DOCUMENT_STATUS = [
        ('pending', 'Pending'),
        ('verified', 'Verified'),
        ('rejected', 'Rejected')
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    pass_type = models.CharField(max_length=20, choices=PASS_TYPES)
    pass_number = models.CharField(max_length=50, unique=True)
    application_date = models.DateTimeField(auto_now_add=True)
    issue_date = models.DateTimeField(null=True, blank=True)
    expiry_date = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    
    # Application Details
    photo = models.ImageField(upload_to='pass_photos/', null=True, blank=True)
    id_proof = models.FileField(upload_to='id_proofs/', null=True, blank=True)
    address_proof = models.FileField(upload_to='address_proofs/', null=True, blank=True)
    document_status = models.CharField(max_length=20, choices=DOCUMENT_STATUS, default='pending')
    rejection_reason = models.TextField(blank=True)
    remarks = models.TextField(blank=True)
    
    # Route Details
    from_station = models.ForeignKey(Station, on_delete=models.SET_NULL, null=True, related_name='passes_from')
    to_station = models.ForeignKey(Station, on_delete=models.SET_NULL, null=True, related_name='passes_to')
    route = models.ForeignKey(Route, on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return f"{self.user.username}'s {self.pass_type} Pass"

    def is_valid(self):
        return self.status == 'active' and self.expiry_date > timezone.now()

class Payment(models.Model):
    PAYMENT_STATUS = [
        ('initiated', 'Initiated'),
        ('pending', 'Pending'),
        ('processing', 'Processing'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
        ('refunded', 'Refunded')
    ]

    PAYMENT_METHODS = [
        ('credit_card', 'Credit Card'),
        ('debit_card', 'Debit Card'),
        ('net_banking', 'Net Banking'),
        ('upi', 'UPI'),
        ('wallet', 'Digital Wallet')
    ]

    bus_pass = models.ForeignKey(BusPass, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_date = models.DateTimeField(auto_now_add=True)
    payment_status = models.CharField(max_length=20, choices=PAYMENT_STATUS, default='initiated')
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHODS, null=True)
    transaction_id = models.CharField(max_length=100, unique=True)
    payment_proof = models.FileField(upload_to='payment_proofs/', null=True, blank=True)
    gateway_response = models.JSONField(null=True, blank=True)
    failure_reason = models.TextField(blank=True)
    refund_details = models.JSONField(null=True, blank=True)

    def __str__(self):
        return f"Payment for {self.bus_pass}"
