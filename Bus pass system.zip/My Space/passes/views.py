from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.utils import timezone
from django.urls import reverse
import uuid
from .forms import UserRegistrationForm, BusPassApplicationForm, UserProfileUpdateForm
from .models import BusPass, Payment

def is_admin(user):
    return user.is_staff

def admin_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None and user.is_staff:
            login(request, user)
            return redirect('admin:index')
        else:
            messages.error(request, 'Invalid admin credentials')
    return render(request, 'passes/admin_login.html')

@user_passes_test(is_admin)
def admin_dashboard(request):
    return redirect('admin:index')

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Registration successful!')
            return redirect('dashboard')
        messages.error(request, 'Registration failed. Please check the form.')
    else:
        form = UserRegistrationForm()
    return render(request, 'passes/register.html', {'form': form})

@login_required
def dashboard(request):
    user_passes = BusPass.objects.filter(user=request.user).order_by('-issue_date')
    context = {
        'user_passes': user_passes,
        'active_passes': user_passes.filter(status='active'),
        'pending_passes': user_passes.filter(status='pending')
    }
    return render(request, 'passes/dashboard.html', context)

@login_required
def apply_bus_pass(request):
    if request.method == 'POST':
        form = BusPassApplicationForm(request.POST)
        if form.is_valid():
            bus_pass = form.save(commit=False)
            bus_pass.user = request.user
            bus_pass.pass_number = f'BP{uuid.uuid4().hex[:8].upper()}'
            
            # Set expiry date based on pass type
            issue_date = timezone.now()
            if bus_pass.pass_type == 'daily':
                expiry_date = issue_date + timezone.timedelta(days=1)
                amount = 50.00
            elif bus_pass.pass_type == 'weekly':
                expiry_date = issue_date + timezone.timedelta(weeks=1)
                amount = 300.00
            elif bus_pass.pass_type == 'monthly':
                expiry_date = issue_date + timezone.timedelta(days=30)
                amount = 1000.00
            elif bus_pass.pass_type == 'quarterly':
                expiry_date = issue_date + timezone.timedelta(days=90)
                amount = 2500.00
            else:  # yearly
                expiry_date = issue_date + timezone.timedelta(days=365)
                amount = 9000.00
            
            bus_pass.expiry_date = expiry_date
            bus_pass.amount = amount
            bus_pass.save()
            
            # Create payment record
            payment = Payment.objects.create(
                bus_pass=bus_pass,
                amount=amount,
                transaction_id=f'TXN{uuid.uuid4().hex[:10].upper()}'
            )
            
            return redirect('payment_process', payment_id=payment.id)
    else:
        form = BusPassApplicationForm()
    return render(request, 'passes/apply_pass.html', {'form': form})

@login_required
def payment_process(request, payment_id):
    payment = Payment.objects.get(id=payment_id)
    if request.method == 'POST':
        # Here you would integrate with a payment gateway
        # For demo purposes, we'll just mark the payment as completed
        payment.payment_status = 'completed'
        payment.save()
        
        # Update bus pass status
        bus_pass = payment.bus_pass
        bus_pass.status = 'active'
        bus_pass.save()
        
        messages.success(request, 'Payment successful! Your bus pass is now active.')
        return redirect('dashboard')
    
    return render(request, 'passes/payment.html', {'payment': payment})

@login_required
def profile(request):
    if request.method == 'POST':
        form = UserProfileUpdateForm(request.POST, request.FILES, instance=request.user.userprofile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('profile')
    else:
        form = UserProfileUpdateForm(instance=request.user.userprofile)
    return render(request, 'passes/profile.html', {'form': form})

def verify_pass(request):
    if request.method == 'POST':
        pass_number = request.POST.get('pass_number')
        try:
            bus_pass = BusPass.objects.get(pass_number=pass_number)
            is_valid = bus_pass.is_valid()
            context = {
                'bus_pass': bus_pass,
                'is_valid': is_valid,
                'message': 'Valid bus pass' if is_valid else 'Invalid or expired bus pass'
            }
        except BusPass.DoesNotExist:
            context = {
                'message': 'Bus pass not found',
                'is_valid': False
            }
        return render(request, 'passes/verify_result.html', context)
    return render(request, 'passes/verify_pass.html')

def home(request):
    return render(request, 'passes/home.html')
