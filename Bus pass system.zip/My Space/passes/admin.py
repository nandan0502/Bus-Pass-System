from django.contrib import admin
from .models import BusPass, Payment, UserProfile, Station, Route
from .custom_admin import CustomUserAdmin, CustomGroupAdmin

@admin.register(BusPass)
class BusPassAdmin(admin.ModelAdmin):
    list_display = ('pass_number', 'user', 'pass_type', 'status', 'issue_date', 'expiry_date', 'amount')
    list_filter = ('pass_type', 'status')
    search_fields = ('pass_number', 'user__username')

@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('transaction_id', 'bus_pass', 'amount', 'payment_date', 'payment_status')
    list_filter = ('payment_status',)
    search_fields = ('transaction_id', 'bus_pass__pass_number')

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'phone_number')
    search_fields = ('user__username', 'phone_number')
    filter_horizontal = ('preferred_routes',)

@admin.register(Station)
class StationAdmin(admin.ModelAdmin):
    list_display = ('name', 'address', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name', 'address')

@admin.register(Route)
class RouteAdmin(admin.ModelAdmin):
    list_display = ('name', 'distance', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name',)
    filter_horizontal = ('stations',)
