from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse
from django.utils import timezone
from .models import BusPass, Payment, UserProfile, Station, Route
from decimal import Decimal

class BusPassSystemTests(TestCase):
    def setUp(self):
        # Create test client
        self.client = Client()
        
        # Create test user
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )
        
        # Create user profile
        self.profile = UserProfile.objects.create(
            user=self.user,
            phone_number='1234567890',
            address='Test Address'
        )
        
        # Create test station and route
        self.station = Station.objects.create(
            name='Test Station',
            address='Station Address'
        )
        
        self.route = Route.objects.create(
            name='Test Route',
            distance=Decimal('10.5')
        )
        self.route.stations.add(self.station)

    def test_user_registration(self):
        # Test user registration
        response = self.client.post(reverse('register'), {
            'username': 'newuser',
            'email': 'new@example.com',
            'password1': 'newpass123',
            'password2': 'newpass123',
            'phone_number': '9876543210',
            'address': 'New Address'
        })
        self.assertEqual(response.status_code, 302)  # Redirect after successful registration
        self.assertTrue(User.objects.filter(username='newuser').exists())

    def test_bus_pass_application(self):
        # Login the user
        self.client.login(username='testuser', password='testpass123')
        
        # Test bus pass application
        response = self.client.post(reverse('apply_pass'), {
            'pass_type': 'monthly',
            'route': self.route.id
        })
        self.assertEqual(response.status_code, 302)  # Redirect to payment
        
        # Verify bus pass creation
        bus_pass = BusPass.objects.filter(user=self.user).first()
        self.assertIsNotNone(bus_pass)
        self.assertEqual(bus_pass.pass_type, 'monthly')
        self.assertEqual(bus_pass.amount, Decimal('1000.00'))

    def test_payment_process(self):
        # Create a bus pass and payment
        bus_pass = BusPass.objects.create(
            user=self.user,
            pass_type='monthly',
            pass_number='BP12345678',
            amount=Decimal('1000.00'),
            status='draft'
        )
        
        payment = Payment.objects.create(
            bus_pass=bus_pass,
            amount=Decimal('1000.00'),
            transaction_id='TXN12345'
        )
        
        # Login and process payment
        self.client.login(username='testuser', password='testpass123')
        response = self.client.post(reverse('payment_process', args=[payment.id]))
        
        # Refresh bus pass from database
        bus_pass.refresh_from_db()
        payment.refresh_from_db()
        
        # Verify payment and bus pass status
        self.assertEqual(payment.payment_status, 'completed')
        self.assertEqual(bus_pass.status, 'active')

    def test_profile_update(self):
        # Login the user
        self.client.login(username='testuser', password='testpass123')
        
        # Test profile update
        response = self.client.post(reverse('profile'), {
            'phone_number': '5555555555',
            'address': 'Updated Address'
        })
        
        # Refresh profile from database
        self.profile.refresh_from_db()
        
        # Verify profile updates
        self.assertEqual(self.profile.phone_number, '5555555555')
        self.assertEqual(self.profile.address, 'Updated Address')

    def test_dashboard_access(self):
        # Test dashboard access without login
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 302)  # Redirect to login
        
        # Test dashboard access with login
        self.client.login(username='testuser', password='testpass123')
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 200)  # Successful access
